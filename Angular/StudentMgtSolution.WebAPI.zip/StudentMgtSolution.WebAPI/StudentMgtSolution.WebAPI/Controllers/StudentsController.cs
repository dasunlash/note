﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentMgtSolution.Core;
using StudentMgtSolution.Core.Entities;

namespace StudentMgtSolution.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly IStudentBAL _studentBAL;
        public StudentsController(IStudentBAL studentBAL)
        {
            _studentBAL = studentBAL;
        }
        // GET: api/Students
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> Get()
        {
            return Ok(await _studentBAL.GetStudents());
        }
        // POST: api/Students
        [HttpPost]
        public async Task<ActionResult<Student>> AddStudent([FromBody] Student student)
        {
            return Ok(await _studentBAL.AddStudent(student));
        }
        // GET: api/Students/1
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetStudent(int id)
        {
            var student = await _studentBAL.GetStudent(id);
            if (student == null)
            {
                return NotFound();
            }
            return Ok(student);
        }

        // GET: api/Students/dasun/lakshan
        [HttpGet("{firstName}/{lastName}")]
        public async Task<ActionResult<Student>> GetStudent(string firstName,string lastName)
        {
            return Ok(await _studentBAL.GetStudent(firstName, lastName));
        }
        // PUT: api/Students or PUT: api/Students/5
        [HttpPut]
        public async Task<ActionResult<Student>> UpdateStudent([FromBody] Student student)
        {
            var studentObj = await _studentBAL.UpdateStudent(student);
            if (studentObj == null)
            {
                return StatusCode(500,$"Unable to update student with id {student.Id}");
            }
            return Ok(studentObj);

        }
        // DELETE: api/Students/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Student>> DeleteStudent(int id)
        {
            var isStudentDeleted = await _studentBAL.DeleteStudent(id);
            if(!isStudentDeleted)
            {
                return StatusCode(500, $"Unable to delete student with id {id}");
            }
            return Ok(isStudentDeleted);
        }
    }
}
