﻿using StudentMgtSolution.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace StudentMgtSolution.Core
{
    public interface IStudentDAL
    {
        Task<List<Student>> GetStudents();

        Task<Student> GetStudent(int id);

        Task<Student> AddStudent(Student student);

        Task<Student> UpdateStudent(Student student);

        Task<bool> DeleteStudent(int id);
        Task<object> GetStudent(string firstName, string lastName);
    }
}
