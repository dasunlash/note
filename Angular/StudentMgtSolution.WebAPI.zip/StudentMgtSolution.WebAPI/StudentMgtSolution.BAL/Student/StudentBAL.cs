﻿using StudentMgtSolution.Core;
using StudentMgtSolution.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace StudentMgtSolution.BAL
{
    public class StudentBAL : IStudentBAL
    {
        private readonly IStudentDAL _studentDAL;

        public StudentBAL(IStudentDAL student)
        {
            _studentDAL = student;
        }

        public Task<Student> AddStudent(Student student)
        {
            try
            {
                return _studentDAL.AddStudent(student);
            }
            catch (Exception ex)
            {

                throw new Exception("unable to save student");
            }
        }

        public Task<bool> DeleteStudent(int id)
        {
            try
            {
                return _studentDAL.DeleteStudent(id);

            }
            catch (Exception ex)
            {

                throw new Exception("unable to delete student");
            }
        }

        public Task<object> GetStudent(string firstName, string lastName)
        {
            try
            {
                return _studentDAL.GetStudent(firstName, lastName);
            }
            catch (Exception ex)
            {

                throw new Exception("unable to get student");
            }
           
        }

        public Task<Student> GetStudent(int id)
        {

            try
            {
                return _studentDAL.GetStudent(id);

            }
            catch (Exception ex)
            {

                throw new Exception("unable to get student");
            }
        }

        public Task<List<Student>> GetStudents()
        {
            try
            {
                return _studentDAL.GetStudents();

            }
            catch (Exception ex)
            {

                throw new Exception("unable to get students");
            }
        }

        public Task<Student> UpdateStudent(Student student)
        {
            try
            {
                return _studentDAL.UpdateStudent(student);
            }
            catch (Exception ex)
            {

                throw new Exception("unable to update student");
            }
           
        }
    }
}
