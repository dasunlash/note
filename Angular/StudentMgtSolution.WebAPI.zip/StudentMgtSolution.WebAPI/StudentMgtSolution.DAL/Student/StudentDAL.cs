﻿using Microsoft.EntityFrameworkCore;
using StudentMgtSolution.Core;
using StudentMgtSolution.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentMgtSolution.DAL
{
    public class StudentDAL: IStudentDAL
    {
        private readonly StudentContext _studentContext;

        public StudentDAL(StudentContext studentContext)
        {
            _studentContext = studentContext;
        }

        public async Task<Student> AddStudent(Student student)
        {
            _studentContext.Students.Add(student);
            await _studentContext.SaveChangesAsync();
            return student;
        }

        public async Task<bool> DeleteStudent(int id)
        {
            if (!_studentContext.Students.Any(student => student.Id == id))
            {
                return false;
            }
            var student = await _studentContext.Students.FirstOrDefaultAsync(x => x.Id == id);
            _studentContext.Students.Remove(student);
            await _studentContext.SaveChangesAsync();
            return true;
        }

        public async Task<object> GetStudent(string firstName, string lastName)
        {
            return await _studentContext.Students.Include(lecture=>lecture.Lecture)
                        .FirstOrDefaultAsync(x => x.FirstName== firstName && x.LastName==lastName);
        }

        public async Task<Student> GetStudent(int id)
        {
            return await _studentContext.Students.Include(lecture => lecture.Lecture).FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<Student>> GetStudents()
        {
           return await _studentContext.Students.Include(lecture => lecture.Lecture).ToListAsync();
        }

        public async Task<Student> UpdateStudent(Student student)
        {
            if (!_studentContext.Students.Any(record => record.Id == student.Id))
            {
                return null;
            }
            _studentContext.Students.Update(student);
            await _studentContext.SaveChangesAsync();
            return student;
        }
    }
}
