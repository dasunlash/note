﻿using Microsoft.EntityFrameworkCore;
using StudentMgtSolution.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace StudentMgtSolution.DAL
{ 
   public class StudentContext:DbContext
    {
        public StudentContext(DbContextOptions<StudentContext> options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        public DbSet<Lecture> Lectures { get; set; }
    }
}
